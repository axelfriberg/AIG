﻿namespace Assets.Scripts.IAJ.Unity.Movement.KinematicMovement
{
    public abstract class TargetedKinematicMovement : KinematicMovement
    {
        public StaticData Target { get;  set; }
    }
}
