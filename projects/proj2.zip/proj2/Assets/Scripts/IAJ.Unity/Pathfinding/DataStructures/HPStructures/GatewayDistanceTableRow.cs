﻿using UnityEngine;

namespace Assets.Scripts.IAJ.Unity.Pathfinding.DataStructures.HPStructures
{
    public class GatewayDistanceTableRow : ScriptableObject
    {
        public GatewayDistanceTableEntry[] entries;
    }
}
